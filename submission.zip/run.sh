#!/bin/sh

python /path/to/OpenNMT-py/translate.py -model /path/to/w15012018.pt  -src /data/input.txt -output /output/output.txt -replace_unk -verbose

